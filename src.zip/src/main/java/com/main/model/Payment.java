package com.main.model;

public enum Payment {
	CASH, CREDITCARD, DEBITCARD, CHECK;
}
